﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using EX_Kamalov;

namespace test_EX_Kamalov
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int year = 2023;
            int group = 123;
            string fio = "Иванов Иван Иванович";

            //string studNumber = GetStudNumber(year, group, fio);
            string expected = "2023.123.ИИИ";

            string actual = StudentNumberGenerator.GetStudNumber(year, group, fio);

            Assert.AreEqual(expected, actual);

        }
    }

}
