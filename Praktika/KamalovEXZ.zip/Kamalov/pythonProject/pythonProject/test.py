import unittest
from main import get_stud_number


class TestGetStudNumber(unittest.TestCase):


   def test_get_stud_number(self):
       year = 2022
       group = 3
       fio = "Иванов Иван Иванович"
       result = get_stud_number(year, group, fio)
       print(result)


if __name__ == '__main__':
   unittest.main()