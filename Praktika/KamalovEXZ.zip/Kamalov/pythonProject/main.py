def get_stud_number(year, group, fio):
   initials = ''.join([name[0].upper() for name in fio.split()])
   stud_number = f"{year}.{group}.{initials}"


   return stud_number