import sys
import cv2
from qrdet import QRDetector
import numpy as np
import webbrowser

from PyQt5.QtWidgets import QApplication, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QWidget, QFileDialog, QTextEdit
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt, QThread, pyqtSignal


class ImageProcessingThread(QThread):
    finished = pyqtSignal(list)
    log_signal = pyqtSignal(str)

    def __init__(self, image_path):
        super().__init__()
        self.image_path = image_path

    def run(self):
        try:
            self.log_signal.emit(f"Обработка файла {self.image_path}\n")
            detector = QRDetector()
            qr_decoder = cv2.QRCodeDetector()
            image = cv2.imread(self.image_path)
            detections = detector.detect(image=image, is_bgr=True)
            qr_codes = []

            if detections:
                for i, detection in enumerate(detections, start=1):
                    data = self.process_qr_detection(image, detection, qr_decoder, i)
                    if data:
                        qr_codes.append(data)
                self.log_signal.emit("Обработка завершена!\n")
            else:
                self.log_signal.emit("QR коды не обнаружены!\n")

            self.finished.emit(qr_codes)
        except Exception as e:
            self.log_signal.emit(f"Ошибка при обработке файла: {e}\n")
            self.finished.emit([])

    def darken_black_pixels(self, image, threshold=50):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        mask = gray < threshold
        image[mask] = (image[mask] * 0.3).astype(np.uint8)
        return image

    def process_qr_detection(self, image, detection, qr_decoder, qr_index):
        polygon = detection.get('polygon_xy')

        if polygon is None:
            return None

        polygon = np.array(polygon, dtype=np.int32)
        x, y, w, h = cv2.boundingRect(polygon)
        cv2.polylines(image, [polygon], True, (0, 255, 0), 2)

        margin = 20
        x = max(x - margin, 0)
        y = max(y - margin, 0)
        w = min(w + 2 * margin, image.shape[1] - x)
        h = min(h + 2 * margin, image.shape[0] - y)

        region = image[y:y + h, x:x + w]

        size = 300
        data = None
        while size <= 2000 and not data:
            resized_region = cv2.resize(region, (size, size), interpolation=cv2.INTER_AREA)
            region_darkened = self.darken_black_pixels(resized_region)

            data, _, _ = qr_decoder.detectAndDecode(region_darkened)
            if data:
                self.log_signal.emit(f"QR Code {qr_index} >>> {data}\n")
            else:
                size += 100
                if size <= 2000:
                    self.log_signal.emit(f"QR Code {qr_index} не считан. Увеличиваем размеры до {size} и пытаемся считать!\n")

        if not data:
            self.log_signal.emit(f"QR Code {qr_index} не считан!\n")
            return None

        return data


class PhotoSelectorApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

        self.worker_thread = None

    def initUI(self):
        self.setWindowTitle('Qr Scanner')
        self.setGeometry(100, 100, 800, 600)

        main_layout = QHBoxLayout()

        log_layout = QVBoxLayout()

        self.btn_select_photo = QPushButton('Выбрать фото', self)
        self.btn_select_photo.setFixedHeight(50)
        self.btn_select_photo.clicked.connect(self.openFileDialog)
        log_layout.addWidget(self.btn_select_photo)

        self.empty_label = QTextEdit(self)
        self.empty_label.setFixedHeight(500)
        self.empty_label.setStyleSheet("background-color: lightgreen;")
        self.empty_label.setReadOnly(True)
        log_layout.addWidget(self.empty_label)

        self.links_layout = QVBoxLayout()
        log_layout.addLayout(self.links_layout)

        photo_layout = QVBoxLayout()

        self.original_photo_label = QLabel(self)
        self.original_photo_label.setFixedWidth(400)
        self.original_photo_label.setAlignment(Qt.AlignCenter)
        self.original_photo_label.setStyleSheet("background-color: lightblue;")
        photo_layout.addWidget(self.original_photo_label)

        self.processed_photo_label = QLabel(self)
        self.processed_photo_label.setFixedWidth(400)
        self.processed_photo_label.setAlignment(Qt.AlignCenter)
        self.processed_photo_label.setStyleSheet("background-color: lightgrey;")
        photo_layout.addWidget(self.processed_photo_label)

        main_layout.addLayout(log_layout)
        main_layout.addLayout(photo_layout)
        self.setLayout(main_layout)

    def openFileDialog(self):
        self.empty_label.clear()
        for i in reversed(range(self.links_layout.count())):
            widget = self.links_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getOpenFileName(self, "Выберите фото", "", "Images (*.png *.jpg);;All Files (*)", options=options)
        if fileName:
            self.displayPhoto(fileName)

    def displayPhoto(self, filePath):
        pixmap = QPixmap(filePath)
        self.original_photo_label.setPixmap(pixmap.scaled(self.original_photo_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.quit()
            self.worker_thread.wait()

        self.worker_thread = ImageProcessingThread(filePath)
        self.worker_thread.log_signal.connect(self.updateLog)
        self.worker_thread.finished.connect(self.onProcessingFinished)
        self.worker_thread.start()

    def updateLog(self, message):
        self.empty_label.append(message)

    def onProcessingFinished(self, qr_codes):
        for code in qr_codes:
            btn = QPushButton(code)
            btn.clicked.connect(lambda checked, url=code: webbrowser.open(url))
            self.links_layout.addWidget(btn)

    def closeEvent(self, event):
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.quit()
            self.worker_thread.wait()
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = PhotoSelectorApp()
    ex.show()
    sys.exit(app.exec_())
